package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.data.model.model.Employees;
import com.example.myapplication.data.model.model.Request;
import com.example.myapplication.databinding.ActivityAuthBinding;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class AuthActivity extends AppCompatActivity {

    private ActivityAuthBinding binding;

    private Employees currentEmployee;
    public ObjectMapper mapper = new ObjectMapper();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityAuthBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.authButton.setOnClickListener((v) -> {
            try {
                auth();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });
    }

    private void auth() throws IOException {
        Pattern pattern = Pattern.compile("^[0-9].{1,7}$", Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(binding.authText.getText());
        boolean matchFound = matcher.find();
        if (matchFound) {
            Request.create("http://172.30.55.78:8080/employees", "GET")
                    .addParam("code", binding.authText.getText().toString())
                    .addHeader("Content-Type", "application/json")
                    .execute(this::onResponseSuccess);
        } else {
            binding.textView2.setText("Вы неправильно ввели код");
        }
    }

    private void onResponseSuccess(String requestResult) {
        try {
            if (!requestResult.equals("null")) {
                currentEmployee = mapper.readValue(requestResult, Employees.class);
                binding.textView2.setText("Добро пожаловать, " + currentEmployee.getName());
                swithTomainActivity();
            } else {
                binding.textView2.setText("Такого пользователя не существует в базе");
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private void swithTomainActivity(){
        Intent myIntent = new Intent(this, MainActivity.class);
        startActivity(myIntent);

    }
}