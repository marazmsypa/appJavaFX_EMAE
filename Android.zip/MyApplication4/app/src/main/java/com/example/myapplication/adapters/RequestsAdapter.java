package com.example.myapplication.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.data.model.model.ExtendedRequests;
import com.example.myapplication.databinding.RequestItemBinding;

import java.text.SimpleDateFormat;
import java.util.List;

public class RequestsAdapter extends RecyclerView.Adapter<RequestsAdapter.RequestsViewHolder>{
    private List<ExtendedRequests> data;

    private final LayoutInflater inflater;

    private OnRequestSelected onRequestSelected;

    public RequestsAdapter(Context context) {
        inflater = LayoutInflater.from(context);
    }

    public RequestsAdapter(List<ExtendedRequests> data, Context context) {
        this(context);
        this.data = data;
    }

    public void setOnPostSelected(OnRequestSelected onRequestSelected) {
        this.onRequestSelected = onRequestSelected;

    }

    public void setData(List<ExtendedRequests> data) {
        this.data = data;
    }
    @NonNull
    @Override
    public RequestsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RequestItemBinding binding = RequestItemBinding.inflate(inflater, parent, false);
        return new RequestsViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull RequestsViewHolder holder, int position) {
        ExtendedRequests request = data.get(position);
        RequestItemBinding binding = holder.getBinding();
        binding.requestDate.setText(new SimpleDateFormat("dd.MM.yyyy").format(request.getDate_start()));
        binding.getRoot().setOnClickListener(v -> {
            if (onRequestSelected != null){
                onRequestSelected.onSelected(request);
            }
        });
        binding.requestSubdivision.setText(request.getEmployee().getName());
        binding.requestType.setText(request.getRequest_type().getName());
    }

    @Override
    public int getItemCount() {
        if (data == null) return 0;
        return data.size();
    }
    public static class RequestsViewHolder extends RecyclerView.ViewHolder {
        private final RequestItemBinding binding;

        public RequestsViewHolder(@NonNull RequestItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        public RequestItemBinding getBinding() {
            return binding;
        }
    }

    public interface OnRequestSelected {
        void onSelected(ExtendedRequests requests);
    }
}
