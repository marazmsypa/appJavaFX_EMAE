package com.example.myapplication.ui.redact;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.util.Pair;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.myapplication.adapters.RequestsAdapter;
import com.example.myapplication.data.model.model.Request;
import com.example.myapplication.data.model.model.Visits;
import com.example.myapplication.databinding.ActivityMainBinding;
import com.example.myapplication.databinding.ActivityRequestChangeBinding;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.android.material.datepicker.MaterialDatePicker;
import com.google.android.material.datepicker.MaterialPickerOnPositiveButtonClickListener;

import java.sql.Time;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.Date;

public class RedactActivity extends AppCompatActivity {

    public static final String DATA_KEY = "important_data";
    private ActivityRequestChangeBinding binding;

    private ObjectMapper mapper = new ObjectMapper();

    private Visits currentVisit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityRequestChangeBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
        Intent intent = getIntent();
        if (intent != null) {
            currentVisit = (Visits) intent.getSerializableExtra(DATA_KEY);
        }
        if (currentVisit.getVisit_date() != null && currentVisit.getVisit_start_time() != null){
            binding.dateText.setText("Дата: " + new SimpleDateFormat("dd.MM.yyyy").format( currentVisit.getVisit_date()));
            binding.timeText.setText("Время: " + currentVisit.getVisit_start_time());
        }
        binding.startVisitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startVisit();
            }
        });
        binding.endVisitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                endVisit();
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void startVisit()  {
        if (currentVisit.getActual_visit_time() != null){
            Toast.makeText(this, "Данная заявка уже была начата", Toast.LENGTH_SHORT).show();
            return;
        }
        Time time = new Time(Instant.now().toEpochMilli());
        currentVisit.setActual_visit_time(time);
        try {
            Request.create("http://172.30.55.78:8080/visits", "PUT")
                    .addJSONstring(mapper.writeValueAsString(currentVisit))
                    .execute(this::onVisitPutSuccess);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }

    private void endVisit()  {
        if (currentVisit.getActual_visit_time() == null){
            Toast.makeText(this, "Данная заявка еще не была начата", Toast.LENGTH_SHORT).show();
            return;
        }
        Time time = new Time(Instant.now().toEpochMilli());
        currentVisit.setVisit_end_time(time);
        if (currentVisit.getSubdivision_visit_end_time() == null){
            Toast.makeText(this, "Сотрудник подразделения еще не отметил окончание посещения", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            Request.create("http://172.30.55.78:8080/visits", "PUT")
                    .addJSONstring(mapper.writeValueAsString(currentVisit))
                    .execute(this::onVisitPutSuccess);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }

    private void onVisitPutSuccess(String resultString){
        if (resultString.equals("\"Query success\"")){
            Toast.makeText(this, "Заявка успешно обновлена", Toast.LENGTH_SHORT);
            finish();
        }
        else {
            Toast.makeText(this, "Не получилось обновить заявку", Toast.LENGTH_SHORT);
        }
    }
}
