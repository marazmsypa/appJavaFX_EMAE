package com.example.myapplication.ui.main;

import androidx.core.util.Pair;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.myapplication.data.model.model.ExtendedRequests;
import com.example.myapplication.data.model.model.Request;
import com.example.myapplication.data.model.model.RequestTypes;
import com.example.myapplication.data.model.model.Subdivisions;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

public class MainViewModel extends ViewModel {
    public static final ObjectMapper mapper = new ObjectMapper();

    private final MutableLiveData<Pair<Date, Date>> date = new MutableLiveData<>();

    private final MutableLiveData<List<Subdivisions>> subdivisionsList = new MutableLiveData<>();

    private final MutableLiveData<List<RequestTypes>> requestTypesList = new MutableLiveData<>();

    private final MutableLiveData<List<ExtendedRequests>> extendedRequests = new MutableLiveData<>();
    private final MutableLiveData<List<ExtendedRequests>> filteredRequestList = new MutableLiveData<>();

    public LiveData<Pair<Date, Date>> getDate() {
        return date;
    }

    public void setDate(Pair<Date, Date> date) {
        this.date.setValue(date);
    }

    public LiveData<List<Subdivisions>> getSubdivisionsList() {
        return subdivisionsList;
    }

    public LiveData<List<RequestTypes>> getRequestTypesList() {
        return requestTypesList;
    }

    public LiveData<List<ExtendedRequests>> getExtendedRequests() {
        return extendedRequests;
    }

    public LiveData<List<ExtendedRequests>> getFilteredRequestList() {
        return filteredRequestList;
    }

    public void setFilteredRequestList(List<ExtendedRequests> list) {
        this.filteredRequestList.setValue(list);
    }

    public void loadSubdivisions() {
        Request.create("http://172.30.55.78:8080/subdivisions", "GET")
                .addHeader("Content-Type", "application/json")
                .execute(this::onResponseSuccessSubdivisions);
    }

    public void loadRequestTypes() {
        Request.create("http://172.30.55.78:8080/request_types", "GET")
                .addHeader("Content-Type", "application/json")
                .execute(this::onResponseSuccessTypes);
    }

    public void loadRequests() {
        Request.create("http://172.30.55.78:8080/requests?extend=true", "GET")
                .addHeader("Content-Type", "application/json")
                .execute(this::onResponseSuccessRequests);
    }

    private void onResponseSuccessSubdivisions(String requestResult) {
        try {
            List<Subdivisions> result = new ArrayList<>(Arrays.asList(mapper.readValue(requestResult, Subdivisions[].class)));

            subdivisionsList.setValue(result);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }

    private void onResponseSuccessTypes(String requestResult) {
        try {
            List<RequestTypes> result = new ArrayList<>(Arrays.asList(mapper.readValue(requestResult, RequestTypes[].class)));

            requestTypesList.setValue(result);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }

    private void onResponseSuccessRequests(String requestResult) {
        try {
            List<ExtendedRequests> result = new ArrayList<>(Arrays.asList(mapper.readValue(requestResult, ExtendedRequests[].class)));

            extendedRequests.setValue(result);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }
}
