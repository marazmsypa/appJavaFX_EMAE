package com.example.myapplication.ui.main;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.util.Pair;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.myapplication.R;
import com.example.myapplication.adapters.RequestsAdapter;
import com.example.myapplication.data.model.model.ExtendedRequests;
import com.example.myapplication.data.model.model.Request;
import com.example.myapplication.data.model.model.RequestTypes;
import com.example.myapplication.data.model.model.Subdivisions;
import com.example.myapplication.data.model.model.Visits;
import com.example.myapplication.databinding.ActivityMainBinding;
import com.example.myapplication.ui.redact.RedactActivity;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.google.android.material.datepicker.MaterialDatePicker;
import com.google.android.material.datepicker.MaterialPickerOnPositiveButtonClickListener;

import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;

    private MainViewModel viewModel;

    private RequestsAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        viewModel = new ViewModelProvider(this).get(MainViewModel.class);

        viewModel.getDate().observe(this, (dateStart) -> loadDate());

        viewModel.getRequestTypesList().observe(this, this::onResponseSuccessTypes);
        viewModel.getSubdivisionsList().observe(this, this::onResponseSuccessSubdivisions);
        viewModel.getExtendedRequests().observe(this, this::onResponseSuccessRequests);
        viewModel.getFilteredRequestList().observe(this, (list) -> {
            if (list.size() == 0) {
                Toast.makeText(this, "Заявок с данными фильтрами нет", Toast.LENGTH_SHORT).show();
            }
            adapter.setData(list);
            adapter.notifyDataSetChanged();
        });

        viewModel.loadSubdivisions();
        viewModel.loadRequestTypes();

        binding.datePickButton.setOnClickListener(view -> opedSelectDateDialog());

        this.adapter = new RequestsAdapter(this);
        adapter.setOnPostSelected(this::onRequestSelected);
        binding.requestsView.setLayoutManager(new LinearLayoutManager(this));
        binding.requestsView.setAdapter(this.adapter);

        binding.subdivisionSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                updateTable();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                updateTable();
            }
        });

        binding.typesSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                updateTable();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                updateTable();
            }
        });

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();

            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_top_bar_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    private boolean isFiltersLoaded() {
        return viewModel.getRequestTypesList().getValue() != null &&
                viewModel.getSubdivisionsList().getValue() != null;
    }

    private void opedSelectDateDialog() {
        MaterialDatePicker<Pair<Long, Long>> pickerRange = MaterialDatePicker.Builder
                .dateRangePicker()
                .build();
        pickerRange.show(getSupportFragmentManager(), MaterialDatePicker.class.getSimpleName());
        pickerRange.addOnPositiveButtonClickListener(new MaterialPickerOnPositiveButtonClickListener<Pair<Long, Long>>() {
            @Override
            public void onPositiveButtonClick(Pair<Long, Long> selection) {
                viewModel.setDate(Pair.create(
                        Date.from(Instant.ofEpochMilli(selection.first + 100000000)),
                        Date.from(Instant.ofEpochMilli(selection.second + 100000000))
                ));
                updateTable();
            }
        });
    }

    private void loadDate() {
        Pair<Date, Date> date = viewModel.getDate().getValue();

        if (date == null) return;

        Date dateStart = date.first;
        Date dateEnd = date.second;

        binding.startDateText.setText(new SimpleDateFormat("dd.MM.yyyy").format(dateStart));
        binding.endDateText.setText(new SimpleDateFormat("dd.MM.yyyy").format(dateEnd));
        binding.startDateText.setVisibility(View.VISIBLE);
        binding.endDateText.setVisibility(View.VISIBLE);
    }

    private void onResponseSuccessSubdivisions(List<Subdivisions> subdivisionsList) {
        List<String> subdivisionsListString = new ArrayList<>();
        subdivisionsListString.add("все");
        for (Subdivisions subd : subdivisionsList) {
            subdivisionsListString.add(subd.getName());
        }
        setupSpinner(binding.subdivisionSpinner, subdivisionsListString);

        if (isFiltersLoaded()) {
            updateTable();
        }
    }

    private void onResponseSuccessTypes(List<RequestTypes> requestTypes) {
        List<String> typesListString = new ArrayList<>();
        typesListString.add("все");
        for (RequestTypes type : requestTypes) {
            typesListString.add(type.getName());
        }
        setupSpinner(binding.typesSpinner, typesListString);

        if (isFiltersLoaded()) {
            updateTable();
        }
    }

    private void setupSpinner(Spinner spinner, List<String> entryList) {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, entryList);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
    }

    private void updateTable() {
        viewModel.loadRequests();
    }

    private void onResponseSuccessRequests(List<ExtendedRequests> extendedRequests) {
        List<Subdivisions> subd = viewModel.getSubdivisionsList().getValue();
        List<RequestTypes> types = viewModel.getRequestTypesList().getValue();

        String selectedSubdivision = binding.subdivisionSpinner.getSelectedItem().toString();
        String selectedType = binding.typesSpinner.getSelectedItem().toString();

        Pair<Date, Date> date = viewModel.getDate().getValue();
        Date selectedDateStart = date == null ? null : date.first;
        Date selectedEndDate = date == null ? null : date.second;

        List<ExtendedRequests> filteredExtendedRequest = new ArrayList<>();
        Subdivisions newsub = new Subdivisions();
        for (Subdivisions sb : subd) {
            if (sb.getName().equals(selectedSubdivision)) newsub = sb;
        }
        RequestTypes newType = new RequestTypes();
        for (RequestTypes sb : types) {
            if (sb.getName().equals(selectedType)) newType = sb;
        }
        for (ExtendedRequests ex : extendedRequests) {
            if (selectedSubdivision.equals("все")) {
                if (selectedType.equals("все")) {
                    if (selectedDateStart != null) {
                        if (ex.getDate_start().after(selectedDateStart) && ex.getDate_start().before(selectedEndDate)) {
                            filteredExtendedRequest.add(ex);
                        }
                    } else {
                        filteredExtendedRequest.add(ex);
                    }
                } else if (ex.getRequest_type().getId() == newType.getId()) {
                    if (selectedDateStart != null) {
                        if (ex.getDate_start().after(selectedDateStart) && ex.getDate_start().before(selectedEndDate)) {
                            filteredExtendedRequest.add(ex);
                        }
                    } else {
                        filteredExtendedRequest.add(ex);
                    }
                }
            } else if (ex.getEmployee().getSubdivision_id() == newsub.getId()) {
                if (selectedType.equals("все")) {
                    if (selectedDateStart != null) {
                        if (ex.getDate_start().after(selectedDateStart) && ex.getDate_start().before(selectedEndDate)) {
                            filteredExtendedRequest.add(ex);
                        }
                    } else {
                        filteredExtendedRequest.add(ex);
                    }
                } else if (ex.getRequest_type().getId() == newType.getId()) {
                    if (selectedDateStart != null) {
                        if (ex.getDate_start().after(selectedDateStart) && ex.getDate_start().before(selectedEndDate)) {
                            filteredExtendedRequest.add(ex);
                        }
                    } else {
                        filteredExtendedRequest.add(ex);
                    }
                }
            }
        }
        viewModel.setFilteredRequestList(filteredExtendedRequest);


    }


    public void onRequestSelected(ExtendedRequests request) {
        Request.create("http://172.30.55.78:8080/visits?id=" + request.getId(), "GET")
                .addHeader("Content-Type", "application/json")
                .execute(this::onResponseVisitSuccess);
    }

    private void onResponseVisitSuccess(String requestResult) {
        Intent intent = new Intent(this, RedactActivity.class);
        if (requestResult.equals("null")) {
            Toast.makeText(this, "Заявка неправильно одобрена", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            intent.putExtra(RedactActivity.DATA_KEY, MainViewModel.mapper.readValue(requestResult, Visits.class));
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
        startActivity(intent);
    }
}


